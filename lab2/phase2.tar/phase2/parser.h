/*
File: parser.h

Description: header file for parser.cpp

Silas Kidd Myers
*/

#ifndef PARSER_H
#define PARSER_H

#include <string>
using namespace std;



#endif /*PARSER_H*/