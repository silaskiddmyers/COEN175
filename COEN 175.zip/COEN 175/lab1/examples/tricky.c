/* tricky.c */

/***
 *** a tricky comment ******/

int main(void)
{
    char c = 0, *s;

    s = "I said \"hello there\"";
    c ++;
    --s;
}
