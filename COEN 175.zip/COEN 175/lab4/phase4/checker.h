/*
 * File:	checker.h
 *
 * Description:	This file contains the public function declarations for the
 *		semantic checker for Simple C.
 */

# ifndef CHECKER_H
# define CHECKER_H
# include <string>
# include "Scope.h"
typedef std::string string;

Scope *openScope();
Scope *closeScope();

void openStruct(const string &name);
void closeStruct(const string &name);

void declareSymbol(const string &name, const Type &type, bool = false);

Symbol *defineFunction(const string &name, const Type &type);
Symbol *checkIdentifier(const string &name);

//Type checkLogicalOR(const Type &left, const Type &right, );
//Type checkMultiply(const Type &left, const Type &right);

Type checkLogical(const Type &left, const Type &right, const string op);
Type checkEquality(const Type &left, const Type &right, const string op);
Type checkRelational(const Type &left, const Type &right, const string op);
Type checkAdditive(const Type &left, const Type &right, const string op);
Type checkMultiplicative(const Type &left, const Type &right, const string op);

Type checkPrefix(const Type &right, const char op, const string specifier = "", const unsigned indirection = 0);
Type checkAddr(Type &right, bool &lvalue);


Type checkAssignment(const Type &left, const Type &right, bool &lvalue);
Type checkStatement(const Type &left, const Type &enclosing, const string op);
Type checkCall(const Type &left, Parameters *params);
Type checkArrayReference(const Type &left, const Type &expression);
Type checkDirectStructReference(const Type &left, const string fieldID);
Type checkIndirectStructReference(const Type &left, const string fieldID);


# endif /* CHECKER_H */
