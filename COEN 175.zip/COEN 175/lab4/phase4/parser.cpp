/*
 * File:	parser.cpp
 *
 * Description:	This file contains the public and private function and
 *		variable definitions for the recursive-descent parser for
 *		Simple C.
 */

#include <cstdlib>
#include <iostream>
#include "checker.h"
#include "tokens.h"
#include "lexer.h"

using namespace std;

static int lookahead;
static string lexbuf;

static Type expression(bool &lvalue);
static void statement(Type enclosing);


/*
 * Function:	error
 *
 * Description:	Report a syntax error to standard error.
 */

static void error()
{
	if (lookahead == DONE)
		report("syntax error at end of file");
	else
		report("syntax error at '%s'", lexbuf);

	exit(EXIT_FAILURE);
}

/*
 * Function:	match
 *
 * Description:	Match the next token against the specified token.  A
 *		failure indicates a syntax error and will terminate the
 *		program since our parser does not do error recovery.
 */

static void match(int t)
{
	if (lookahead != t)
		error();

	lookahead = lexan(lexbuf);
}

/*
 * Function:	number
 *
 * Description:	Match the next token as a number and return its value.
 */

static unsigned number()
{
	string buf;

	buf = lexbuf;
	match(NUM);
	return strtoul(buf.c_str(), NULL, 0);
}

/*
 * Function:	identifier
 *
 * Description:	Match the next token as an identifier and return its name.
 */

static string identifier()
{
	string buf;

	buf = lexbuf;
	match(ID);
	return buf;
}

/*
 * Function:	isSpecifier
 *
 * Description:	Return whether the given token is a type specifier.
 */

static bool isSpecifier(int token)
{
	return token == INT || token == CHAR || token == STRUCT;
}

/*
 * Function:	specifier
 *
 * Description:	Parse a type specifier.  Simple C has int, char, and
 *		structure types.
 *
 *		specifier:
 *		  int
 *		  char
 *		  struct identifier
 */

static string specifier()
{
	if (lookahead == INT)
	{
		match(INT);
		return "int";
	}

	if (lookahead == CHAR)
	{
		match(CHAR);
		return "char";
	}

	match(STRUCT);
	return identifier();
}

/*
 * Function:	pointers
 *
 * Description:	Parse pointer declarators (i.e., zero or more asterisks).
 *
 *		pointers:
 *		  empty
 *		  * pointers
 */

static unsigned pointers()
{
	unsigned count = 0;

	while (lookahead == '*')
	{
		match('*');
		count++;
	}

	return count;
}

/*
 * Function:	declarator
 *
 * Description:	Parse a declarator, which in Simple C is either a scalar
 *		variable or an array, both with optional pointer
 *		declarators, or a callback (i.e., a simple function
 *		pointer).
 *
 *		declarator:
 *		  pointers identifier
 *		  pointers identifier [ num ]
 *		  pointers ( * identifier ) ( )
 */

static void declarator(const string &typespec)
{
	unsigned indirection;
	string name;

	indirection = pointers();

	if (lookahead == '(')
	{
		match('(');
		match('*');
		name = identifier();
		declareSymbol(name, Callback(typespec, indirection));
		match(')');
		match('(');
		match(')');
	}
	else
	{
		name = identifier();

		if (lookahead == '[')
		{
			match('[');
			declareSymbol(name, Array(typespec, indirection, number()));
			match(']');
		}
		else
			declareSymbol(name, Scalar(typespec, indirection));
	}
}

/*
 * Function:	declaration
 *
 * Description:	Parse a local variable declaration.  Global declarations
 *		are handled separately since we need to detect a function
 *		as a special case.
 *
 *		declaration:
 *		  specifier declarator-list ';'
 *
 *		declarator-list:
 *		  declarator
 *		  declarator , declarator-list
 */

static void declaration()
{
	string typespec;

	typespec = specifier();
	declarator(typespec);

	while (lookahead == ',')
	{
		match(',');
		declarator(typespec);
	}

	match(';');
}

/*
 * Function:	declarations
 *
 * Description:	Parse a possibly empty sequence of declarations.
 *
 *		declarations:
 *		  empty
 *		  declaration declarations
 */

static void declarations()
{
	while (isSpecifier(lookahead))
		declaration();
}

/*
 * Function:	primaryExpression
 *
 * Description:	Parse a primary expression.
 *
 *		primary-expression:
 *		  ( expression )
 *		  identifier
 *		  character
 *		  string
 *		  num
 */

static Type primaryExpression(bool lparen, bool &lvalue)
{
 	Type left;
	//cout << "primary expression lvalue: " << lvalue << endl;
    if (lparen) {
        left = expression(lvalue);
        match(')');
    }
    else if (lookahead == STRING) {
        match(STRING);
        left = Array("char", 0, lexbuf.length());
        lvalue = false;
    }
    else if (lookahead == NUM) {
        match(NUM);
        left = Scalar("int");
        lvalue = false;
    }
	else if (lookahead == CHARACTER) {
		match(CHARACTER);
		left = Scalar("int");
		lvalue = false;
	}
    else if (lookahead == ID) {
		Symbol *symbol = checkIdentifier(identifier());
		left = symbol->type();
		if(left.isCallback() || left.isScalar())
			lvalue = true;
		else
			lvalue = false;
    }
    else {
        error();
    }
    return left;
}

/*
 * Function:	postfixExpression
 *
 * Description:	Parse a postfix expression.
 *
 *		postfix-expression:
 *		  primary-expression
 *		  postfix-expression [ expression ]
 *		  postfix-expression ( expression-list )
 *		  postfix-expression ( )
 *		  postfix-expression . identifier
 *		  postfix-expression -> identifier
 *
 *		expression-list:
 *		  expression
 *		  expression , expression-list
 */

static Type postfixExpression(bool lparen, bool &lvalue)
{
	Type left;
	left = primaryExpression(lparen, lvalue);
	while (1)
	{
		if (lookahead == '[')
		{
			match('[');
			lvalue = false;
			Type right = expression(lvalue);
			match(']');	
			left = checkArrayReference(left, right);
			lvalue = true;
			cout << "index" << endl;
		}
		else if (lookahead == '(')
		{
			match('(');
			Parameters* params = new Parameters();
			if (lookahead != ')')
			{
				params->push_back(expression(lvalue));

				while (lookahead == ',')
				{
					match(',');
					params->push_back(expression(lvalue));
				}
			}

			match(')');
			left = checkCall(left, params);
			lvalue = false;
			cout << "call" << endl;
		}
		else if (lookahead == '.')
		{
			match('.');
			
			left = checkDirectStructReference(left, identifier());
			if(left.isArray())
				lvalue = false;
			else lvalue = true;
			cout << "dot" << endl;
		}
		else if (lookahead == ARROW)
		{
			match(ARROW);
			left = checkIndirectStructReference(left, identifier());
			if(left.isArray())
				lvalue = false;
			else lvalue = true;
			cout << "arrow" << endl;
		}
		else
			break;
	}
	return left;
}

/*
 * Function:	prefixExpression
 *
 * Description:	Parse a prefix expression.
 *
 *		prefix-expression:
 *		  postfix-expression
 *		  ! prefix-expression
 *		  - prefix-expression
 *		  * prefix-expression
 *		  & prefix-expression
 *		  sizeof prefix-expression
 *		  sizeof ( specifier pointers )
 *		  ( specifier pointers ) prefix-expression
 *
 *		This grammar is still ambiguous since "sizeof(type) * n"
 *		could be interpreted as a multiplicative expression or as a
 *		cast of a dereference.  The correct interpretation is the
 *		former, as the latter makes little sense semantically.  We
 *		resolve the ambiguity here by always consuming the "(type)"
 *		as part of the sizeof expression.
 */

static Type prefixExpression(bool &lvalue)
{
	Type type;
	if (lookahead == '!')
	{
		match('!');
		Type right = prefixExpression(lvalue);
		type = checkPrefix(right, '!');
		lvalue = false;
		cout << "check !" << endl;
	}
	else if (lookahead == '-')
	{
		match('-');
		Type right = prefixExpression(lvalue);
		type = checkPrefix(right, '-');
		lvalue = false;
		cout << " check -" << endl;
	}
	else if (lookahead == '*')
	{
		match('*');
		Type right = prefixExpression(lvalue);
		type = checkPrefix(right, '*');
		lvalue = true;
		cout << "check *" << endl;
	}
	else if (lookahead == '&')
	{
		match('&');
		Type right = prefixExpression(lvalue);
		type = checkAddr(right, lvalue);
		lvalue = false;
		cout << "check &" << endl;
	}
	else if (lookahead == SIZEOF)
	{
		match(SIZEOF);

		if (lookahead == '(')
		{
			match('(');

			if (isSpecifier(lookahead))
			{
				specifier();
				pointers();
				match(')');
			}
			else {
				Type left = postfixExpression(true, lvalue);
				type = checkPrefix(left, 's');
				lvalue = false;
			}
		}
		else
		{
			Type right = prefixExpression(lvalue);
			type = checkPrefix(right, 's');
			lvalue = false;
		}
		cout << "sizeof" << endl;
	}
	else if (lookahead == '(')
	{
		match('(');

		if (isSpecifier(lookahead))
		{
			string spec = specifier();
			unsigned indirection = pointers();
			match(')');
			Type right = prefixExpression(lvalue);
			type = checkPrefix(right, 'c', spec, indirection);
			lvalue = false;
			cout << "check cast" << endl;

		}
		else
			type = postfixExpression(true, lvalue);
	}
	else
		type = postfixExpression(false, lvalue);
	return type;
}

/*
 * Function:	multiplicativeExpression
 *
 * Description:	Parse a multiplicative expression.
 *
 *		multiplicative-expression:
 *		  prefix-expression
 *		  multiplicative-expression * prefix-expression
 *		  multiplicative-expression / prefix-expression
 *		  multiplicative-expression % prefix-expression
 */

static Type multiplicativeExpression(bool &lvalue)
{
	Type left = prefixExpression(lvalue);

	while (1)
	{
		if (lookahead == '*')
		{
			match('*');
			Type right = prefixExpression(lvalue);
			left = checkMultiplicative(left, right, "*");
			lvalue = false;
			cout << "mul" << endl;
		}
		else if (lookahead == '/')
		{
			match('/');
			Type right = prefixExpression(lvalue);
			left = checkMultiplicative(left, right, "/");
			lvalue = false;
			cout << "check /" << endl;
		}
		else if (lookahead == '%')
		{
			match('%');
			Type right = prefixExpression(lvalue);
			left = checkMultiplicative(left, right, "%");
			lvalue = false;
			cout << "check %" << endl;
		}
		else
			return left;
	}
	
}

/*
 * Function:	additiveExpression
 *
 * Description:	Parse an additive expression.
 *
 *		additive-expression:
 *		  multiplicative-expression
 *		  additive-expression + multiplicative-expression
 *		  additive-expression - multiplicative-expression
 */

static Type additiveExpression(bool &lvalue)
{
	Type left = multiplicativeExpression(lvalue);

	while (1)
	{
		if (lookahead == '+')
		{
			match('+');
			Type right = multiplicativeExpression(lvalue);
			left = checkAdditive(left, right, "+");
			lvalue = false;
			cout << "check add" << endl;
		}
		else if (lookahead == '-')
		{
			match('-');
			Type right = multiplicativeExpression(lvalue);
			left = checkAdditive(left, right, "-");
			lvalue = false;
			cout << "check subtract" << endl;
		}
		else
			break;
	}
	return left;
}

/*
 * Function:	relationalExpression
 *
 * Description:	Parse a relational expression.  Note that Simple C does not
 *		have shift operators, so we go immediately to additive
 *		expressions.
 *
 *		relational-expression:
 *		  additive-expression
 *		  relational-expression < additive-expression
 *		  relational-expression > additive-expression
 *		  relational-expression <= additive-expression
 *		  relational-expression >= additive-expression
 */

static Type relationalExpression(bool &lvalue)
{
	Type left = additiveExpression(lvalue);

	while (1)
	{
		if (lookahead == '<')
		{
			match('<');
			Type right = additiveExpression(lvalue);
			left = checkRelational(left, right, "<");
			lvalue = false;
			cout << "ltn" << endl;
		}
		else if (lookahead == '>')
		{
			match('>');
			Type right = additiveExpression(lvalue);
			left = checkRelational(left, right, ">");
			lvalue = false;
			cout << "gtn" << endl;
		}
		else if (lookahead == LEQ)
		{
			match(LEQ);
			Type right = additiveExpression(lvalue);
			checkRelational(left, right,"<=");
			lvalue = false;
			cout << "leq" << endl;
		}
		else if (lookahead == GEQ)
		{
			match(GEQ);
			Type right = additiveExpression(lvalue);
			checkRelational(left, right, ">=");
			lvalue = false;
			cout << "geq" << endl;
		}
		else
			break;
	}
	return left;
}

/*
 * Function:	equalityExpression
 *
 * Description:	Parse an equality expression.
 *
 *		equality-expression:
 *		  relational-expression
 *		  equality-expression == relational-expression
 *		  equality-expression != relational-expression
 */

static Type equalityExpression(bool &lvalue)
{
	Type left = relationalExpression(lvalue);

	while (1)
	{
		if (lookahead == EQL)
		{
			match(EQL);
			Type right = relationalExpression(lvalue);
			left = checkEquality(left, right, "==");
			lvalue = false;
			cout << "check ==" << endl;
		}
		else if (lookahead == NEQ)
		{
			match(NEQ);
			Type right = relationalExpression(lvalue);
			left = checkEquality(left, right, "!=");
			lvalue = false;
			cout << "check !=" << endl;
		}
		else
			break;
	}
	return left;
}

/*
 * Function:	logicalAndExpression
 *
 * Description:	Parse a logical-and expression.  Note that Simple C does
 *		not have bitwise-and expressions.
 *
 *		logical-and-expression:
 *		  equality-expression
 *		  logical-and-expression && equality-expression
 */

static Type logicalAndExpression(bool &lvalue)
{
	Type left = equalityExpression(lvalue);

	while (lookahead == AND)
	{
		match(AND);
		Type right = equalityExpression(lvalue);
		left = checkLogical(left, right, "&&");
		lvalue = false;
		cout << "check &&" << endl;
	}
	return left;
}

/*
 * Function:	expression
 *
 * Description:	Parse an expression, or more specifically, a logical-or
 *		expression, since Simple C does not allow comma or
 *		assignment as an expression operator.
 *
 *		expression:
 *		  logical-and-expression
 *		  expression || logical-and-expression
 */

static Type expression(bool &lvalue)
{
	Type left = logicalAndExpression(lvalue);

	while (lookahead == OR) {
		match(OR);
		Type right = logicalAndExpression(lvalue);
		left = checkLogical(left, right, "||");
		lvalue = false;
		cout << "check ||" << endl;
	}
	return left;
}

/*
 * Function:	statements
 *
 * Description:	Parse a possibly empty sequence of statements.  Rather than
 *		checking if the next token starts a statement, we check if
 *		the next token ends the sequence, since a sequence of
 *		statements is always terminated by a closing brace.
 *
 *		statements:
 *		  empty
 *		  statement statements
 */

static void statements(Type enclosing)
{
	while (lookahead != '}')
		statement(enclosing);
}

/*
 * Function:	assignment
 *
 * Description:	Parse an assignment statement.
 *
 *		assignment:
 *		  expression = expression
 *		  expression
 */

static void assignment(bool &lvalue1)
{
	Type left = expression(lvalue1);
	Type right;
	if (lookahead == '=')
	{
		match('=');
		bool lvalue2 = lvalue1;
		right = expression(lvalue1);
		//cout << "assignment lvalue: " << lvalue1 << endl;	
		checkAssignment(left, right, lvalue2);
	}

}

/*
 * Function:	statement
 *
 * Description:	Parse a statement.  Note that Simple C has so few
 *		statements that we handle them all in this one function.
 *
 *		statement:
 *		  { declarations statements }
 *		  return expression ;
 *		  while ( expression ) statement
 *		  for ( assignment ; expression ; assignment ) statement
 *		  if ( expression ) statement
 *		  if ( expression ) statement else statement
 *		  assignment ;
 */

static void statement(Type enclosing)
{
	Type type;
	bool lvalue = false;
	if (lookahead == '{')
	{
		match('{');
		openScope();
		declarations();
		statements(type);
		closeScope();
		match('}');
	}
	else if (lookahead == RETURN)
	{
		match(RETURN);
		//lvalue = false;
		type = expression(lvalue);		
		type = checkStatement(type, enclosing, "RETURN");
		match(';');

	}
	else if (lookahead == WHILE)
	{
		match(WHILE);
		match('(');
		//lvalue = false;
		type = expression(lvalue);
		match(')');
		type = checkStatement(type, enclosing, "WHILE");
		statement(type);
	}
	else if (lookahead == FOR)
	{
		match(FOR);
		match('(');
		assignment(lvalue);
		match(';');
		//lvalue = false;
		type = expression(lvalue);		
		type = checkStatement(type, enclosing, "FOR");
		match(';');
		assignment(lvalue);
		match(')');

		statement(type);
	}
	else if (lookahead == IF)
	{
		match(IF);
		match('(');
		//lvalue = false;
		type = expression(lvalue);
		match(')');
		type = checkStatement(type, enclosing, "IF");
		statement(type);

		if (lookahead == ELSE)
		{
			match(ELSE);
			statement(type);
		}
	}
	else
	{
		assignment(lvalue);
		match(';');
	}
}

/*
 * Function:	parameter
 *
 * Description:	Parse a parameter, which in Simple C is always either a
 *		simple variable with optional pointer declarators, or a
 *		callback (i.e., a simple function pointer)
 *
 *		parameter:
 *		  specifier pointers identifier
 *		  specifier pointers ( * identifier ) ( )
 */

static Type parameter()
{
	unsigned indirection;
	string typespec, name;
	Type type;

	typespec = specifier();
	indirection = pointers();

	if (lookahead == '(')
	{
		match('(');
		match('*');
		name = identifier();
		type = Callback(typespec, indirection);
		declareSymbol(name, type, true);
		match(')');
		match('(');
		match(')');
	}
	else
	{
		name = identifier();
		type = Scalar(typespec, indirection);
		declareSymbol(name, type, true);
	}

	return type;
}

/*
 * Function:	parameters
 *
 * Description:	Parse the parameters of a function, but not the opening or
 *		closing parentheses.
 *
 *		parameters:
 *		  void
 *		  parameter-list
 *
 *		parameter-list:
 *		  parameter
 *		  parameter , parameter-list
 */

static Parameters *parameters()
{
	Parameters *params;

	params = new Parameters();

	if (lookahead == VOID)
		match(VOID);

	else
	{
		params->push_back(parameter());

		while (lookahead == ',')
		{
			match(',');
			params->push_back(parameter());
		}
	}

	return params;
}

/*
 * Function:	globalDeclarator
 *
 * Description:	Parse a declarator, which in Simple C is either a scalar
 *		variable, an array, or a function, all with optional
 *		pointer	declarators, or a callback (i.e., a simple function
 *		pointer).
 *
 *		global-declarator:
 *		  pointers identifier
 *		  pointers identifier ( )
 *		  pointers identifier [ num ]
 *		  pointers ( * identifier ) ( )
 */

static void globalDeclarator(const string &typespec)
{
	unsigned indirection;
	string name;

	indirection = pointers();

	if (lookahead == '(')
	{
		match('(');
		match('*');
		name = identifier();
		declareSymbol(name, Callback(typespec, indirection));
		match(')');
		match('(');
		match(')');
	}
	else
	{
		name = identifier();

		if (lookahead == '(')
		{
			match('(');
			declareSymbol(name, Function(typespec, indirection));
			match(')');
		}
		else if (lookahead == '[')
		{
			match('[');
			declareSymbol(name, Array(typespec, indirection, number()));
			match(']');
		}
		else
			declareSymbol(name, Scalar(typespec, indirection));
	}
}

/*
 * Function:	remainingDeclarators
 *
 * Description:	Parse any remaining global declarators after the first.
 *
 * 		remaining-declarators:
 * 		  ;
 * 		  , global-declarator remaining-declarators
 */

static void remainingDeclarators(const string &typespec)
{
	while (lookahead == ',')
	{
		match(',');
		globalDeclarator(typespec);
	}

	match(';');
}

/*
 * Function:	globalOrFunction
 *
 * Description:	Parse a global declaration or function definition.
 *
 * 		global-or-function:
 * 		  struct identifier { declaration declarations } ;
 * 		  specifier pointers identifier remaining-decls
 * 		  specifier pointers identifier ( ) remaining-decls
 * 		  specifier pointers identifier [ num ] remaining-decls
 * 		  specifier pointers identifier ( parameters ) { ... }
 */

static void globalOrFunction()
{
	unsigned indirection;
	string typespec, name;

	typespec = specifier();

	if (typespec != "int" && typespec != "char" && lookahead == '{')
	{
		openStruct(typespec);
		match('{');
		declaration();
		declarations();
		closeStruct(typespec);
		match('}');
		match(';');
	}
	else
	{
		indirection = pointers();

		if (lookahead == '(')
		{
			match('(');
			match('*');
			name = identifier();
			declareSymbol(name, Callback(typespec, indirection));
			match(')');
			match('(');
			match(')');
			remainingDeclarators(typespec);
		}
		else
		{
			name = identifier();

			if (lookahead == '[')
			{
				match('[');
				declareSymbol(name, Array(typespec, indirection, number()));
				match(']');
				remainingDeclarators(typespec);
			}
			else if (lookahead == '(')
			{
				match('(');

				if (lookahead == ')')
				{
					declareSymbol(name, Function(typespec, indirection));
					match(')');
					remainingDeclarators(typespec);
				}
				else
				{
					openScope();
					Type func = Function(typespec, indirection, parameters());
					defineFunction(name, func);
					match(')');
					match('{');
					declarations();
					statements(Scalar(typespec, indirection));
					closeScope();
					match('}');
				}
			}
			else
			{
				declareSymbol(name, Scalar(typespec, indirection));
				remainingDeclarators(typespec);
			}
		}
	}
}

/*
 * Function:	main
 *
 * Description:	Analyze the standard input stream.
 */

int main()
{
	openScope();
	lookahead = lexan(lexbuf);

	while (lookahead != DONE)
		globalOrFunction();

	closeScope();
	exit(EXIT_SUCCESS);
}
