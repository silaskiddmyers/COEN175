int x;
int a, *b[10];

int *f(int x, int f)
{
    int y;

    if (f == x + y) {
	int x, f, y, z;

	z = f + 1 + y;

	if (z > a) {
	    int a;
	    a = 0;
	    b[0] = &a;
	}
    }
}
